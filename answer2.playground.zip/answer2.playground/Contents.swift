//: Playground - noun: a place where people can play

import UIKit

let factors:[Int] = [1,2,3,4,5,6,7,8,9]

let now=factors.reduce(1, *)
print(now)